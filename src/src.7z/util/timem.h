#ifndef _TIME_M_HEADER_
#define _TIME_M_HEADER_

namespace Util{
	void UpdateFrameTime();
	float FrameTime();
	int Sign(int val);
	float Sign(float val);
}


#endif